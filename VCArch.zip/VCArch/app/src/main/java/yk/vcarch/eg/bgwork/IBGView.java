package yk.vcarch.eg.bgwork;

import yk.vcarch.IView;

public interface IBGView extends IView {
    void showResult(String result);
    void showError(String url);
    void showLoading();
}
