package yk.vcarch.eg.bgwork;

import android.os.Bundle;

import java.util.Random;

import yk.vcarch.BaseController;

public class BgWorkController extends BaseController<IBGView> {
    public static final String EXTRA_URL = "url";
    String url;

    public BgWorkController(BgWorkActivity view) {
        super(view);
    }

    @Override
    public void init(Bundle savedInstanceState) {
        super.init(savedInstanceState);
        url = intent.getStringExtra(EXTRA_URL);
        queryData(url);
        getView().showLoading();
    }

    public void queryData(final String url) {
        submitTaskOnMainBg(new CommonBgWork<String>() {
            @Override
            public int work() {
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    return STAT_INT;
                }
                if (new Random().nextBoolean()) {
                    return STAT_ERROR;
                }
                setResult(url + ",success");
                return STAT_SUCCESS;
            }

            @Override
            public void doneOnMain(IBGView view, String result, int resultCode) {
                if (resultCode == STAT_SUCCESS) {
                    view.showResult(result);
                } else {
                    view.showError(url);
                }
            }
        });
    }
}
