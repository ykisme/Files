package yk.vcarch.eg.bgwork;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import yk.vcarch.BaseActivity;
import yk.vcarch.eg.R;

import static yk.vcarch.eg.bgwork.BgWorkController.EXTRA_URL;

public class BgWorkActivity extends BaseActivity<IBGView, BgWorkController> implements IBGView {
    TextView tvResult;

    public static Intent from(Context context, String url) {
        return new Intent(context.getApplicationContext(), BgWorkActivity.class).putExtra(EXTRA_URL, url);
    }

    @Override
    protected void findViews() {
        tvResult = findViewById(R.id.tv_result);
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_bg_work;
    }

    @Override
    public void showResult(String data) {
        dismissDialogIfNeeded();
        tvResult.setText(data);
    }

    @Override
    public void showError(String msg) {
        dismissDialogIfNeeded();
        AlertDialog alertDialog = new AlertDialog.Builder(this).setTitle("alert")
                .setMessage("error:" + msg).setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                }).show();
        showDialog(alertDialog);
    }

    @Override
    public void showLoading() {
        ProgressDialog loadingDialog = ProgressDialog.show(this, null, "loading");
        showDialog(loadingDialog);
    }
}