package yk.vcarch.eg.main;

import android.view.View;

import yk.vcarch.BaseActivity;
import yk.vcarch.eg.R;
import yk.vcarch.eg.bgwork.BgWorkActivity;

public class MainActivity extends BaseActivity {

    @Override
    protected int getLayout() {
        return R.layout.activity_main;
    }

    @Override
    protected void initViews() {
        findViewById(R.id.btn_temple1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(BgWorkActivity.from(getApplication(),"url_test"));
            }
        });
    }
}