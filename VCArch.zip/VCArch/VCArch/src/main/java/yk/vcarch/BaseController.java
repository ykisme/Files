package yk.vcarch;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.lang.ref.WeakReference;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BaseController<V extends IView> {
    private final Handler mainHandle = new Handler(Looper.getMainLooper());
    private ExecutorService mainBgWorker;
    final Object lock = new Object();
    final private WeakReference<V> view;
    @NonNull
    protected Intent intent = new Intent();
    @Nullable
    protected Bundle savedInstanceState;
    public BaseController(V view) {
        this.view = new WeakReference<>(view);
    }

    //注意判空
    @Nullable
    protected V getView() {
        return this.view.get();
    }

    protected ExecutorService getMainBgWorker() {
        if (mainBgWorker == null) {
            synchronized (lock) {
                if (mainBgWorker == null) {
                    mainBgWorker = Executors.newSingleThreadExecutor();
                }
            }
        }
        return mainBgWorker;
    }

    protected void submitTaskOnMainBg(CommonBgWork<?> commonBgWork) {
        getMainBgWorker().submit(commonBgWork);
    }

    protected void runOnMain(Runnable r) {
        mainHandle.post(r);
    }

    public void onDestroy() {
        getMainBgWorker().shutdownNow();
    }

    public void setIntent(@NonNull Intent intent) {
        this.intent = intent;
    }

    public void init(Bundle savedInstanceState) {
        this.savedInstanceState = savedInstanceState;
    }

    public abstract class CommonBgWork<R> implements Runnable {
        public final int STAT_INT = -1;
        public final int STAT_SUCCESS = 0;
        public final int STAT_ERROR = 1;
        R result;

        public void setResult(R r) {
            result = r;
        }

        //返回-1，表示提前终止
        //返回0，表示成功
        public abstract int work();

        public void doneBg(V view, R result, int resultCode) {
        }

        ;

        public void doneOnMain(V view, R result, int resultCode) {
        }

        @Override
        public void run() {
            final int i = work();
            if (i == STAT_INT) return;
            final V view = getView();
            if (view == null) return;
            doneBg(view, result, i);
            runOnMain(new Runnable() {
                @Override
                public void run() {
                    doneOnMain(view, result, i);
                }
            });
        }
    }
}
