package yk.vcarch;

public interface IView {
}
