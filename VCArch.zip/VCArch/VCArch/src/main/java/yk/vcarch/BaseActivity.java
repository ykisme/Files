package yk.vcarch;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.WindowManager;

import androidx.annotation.Keep;
import androidx.annotation.LayoutRes;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.joor.Reflect;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public abstract class BaseActivity<V extends IView, C extends BaseController<V>> extends AppCompatActivity
        implements IView {
    private static final String TAG = "BaseActivity";
    @Nullable
    protected C controller;
    protected Handler mainHandle = new Handler(Looper.getMainLooper());
    Dialog dialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        commonSetWindow();
        customSetWindow();
        super.onCreate(savedInstanceState);
        int layout = getLayout();
        if (layout > 0) {
            setContentView(layout);
        }
        findViews();
        controller = productControl();
        setController();
        initViews();
        onInit(savedInstanceState);
    }

    final void setController() {
        if (controller != null) {
            controller.setIntent(getIntent() == null ? new Intent() : getIntent());
        }
    }

    protected void findViews() {
    }

    @Keep
    protected void onInit(Bundle savedInstanceState) {
        if (controller != null) {
            controller.init(savedInstanceState);
        }
    }

    protected void initViews() {
    }

    @LayoutRes
    protected abstract int getLayout();

    @Nullable
    protected C productControl() {
        if (this.getClass().getGenericSuperclass() instanceof ParameterizedType) {
            ParameterizedType parameterizedType = ((ParameterizedType) this.getClass().getGenericSuperclass());
            Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
            Log.d(TAG, "productControl: actualTypeArguments.length:" + actualTypeArguments.length);
            if (actualTypeArguments.length == 2) {
                Log.d(TAG, "productControl: actualTypeArguments 0:" + actualTypeArguments[0] +
                        " actualTypeArguments 1:" + actualTypeArguments[1]);
                Class<?> viewClass = null;
                Class<?> controlClass = null;
                for (Type type : actualTypeArguments) {
                    if (type instanceof Class && BaseController.class.isAssignableFrom((Class<?>) type)) {
                        controlClass = (Class<?>) type;
                    }
                    if (type instanceof Class && IView.class.isAssignableFrom((Class<?>) type)) {
                        viewClass = (Class<?>) type;
                    }
                }
                Log.d(TAG, "productControl: controlClass:" + controlClass + " viewClass:" + viewClass);
                if (viewClass != null && controlClass != null) {
                    return Reflect.onClass(controlClass).create(this).get();
                }
            }
        }
        return null;
    }

    //页面特别设置Window的地方
    protected void customSetWindow() {
    }

    //统一设置Window属性的地方
    private void commonSetWindow() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);//防止录屏
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (controller != null) {
            controller.onDestroy();
        }
        dismissDialogIfNeeded();
    }

    protected void dismissDialogIfNeeded() {
        if (this.dialog != null) {
            this.dialog.dismiss();
            this.dialog = null;
        }
    }

    protected void showDialog(Dialog dialog) {
        dismissDialogIfNeeded();
        this.dialog = dialog;
        if (!dialog.isShowing()) {
            dialog.show();
        }
    }

    protected void startActivity(Class<? extends Activity> activity) {
        startActivity(new Intent(getApplicationContext(), activity));
    }
}
